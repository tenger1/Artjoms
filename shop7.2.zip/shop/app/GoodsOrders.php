<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GoodsOrders extends Model
{
    protected $table = 'goods_orders';
}
