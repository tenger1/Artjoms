<?php

namespace App\Http\Controllers;

use App\Goods;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

class OrdersController extends Controller
{
    public function buyAction($id){
        $product = Goods::find($id);
        if($product){
            return view('order', ['goods_id' => $id]);
        }
    }
    
    public function finishAction(){
     
$servername = "localhost";
$username = "user1";
$password = "12345";
$dbname = "shop";       

$conn = mysqli_connect($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
define("PREFIX","goods"); //Префикс если нужно



    $amount = ($_GET["amount"]);
    
    
    $city =($_GET["city"]);
    $phone =($_GET["phone"]);
    $customer_name = (["customer_name"]);
    $product_id = ($_GET["product_id"]);
     
    $sql = "INSERT INTO goods__orders (goods_id, order_id, amount) VALUES ($product_id, '1', $amount)";
    
$summ = "SELECT price FROM goods WHERE id = '$product_id'";

$result=$conn->query("SELECT * FROM goods WHERE id = '$product_id'");

   
  while($row = mysql_fetch_array($result)){
    $id=$row['ID'];
    $name=$row['Name'];
    $color=$row['color'];
    $country=$row['country'];
    $destriprion=$row['description'];
    $price=$row['price'];
 
    echo "<p>$price</p>";
    }
    
exit;

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
  
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

mysqli_close($conn);
    
}
  
    
}