<?php

namespace App\Http\Controllers;

use App\Goods;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

class OrdersController extends Controller
{
    public function buyAction($id){
        $product = Goods::find($id);
        if($product){
            return view('order', ['goods_id' => $id]);
        }
    }
    
     
public function finishAction(){
        

$servername = "127.0.0.1:3308";
$username = "user1";
$password = "12345";
$dbname = "shop";       

//$conn = mysqli_connect($servername, $username, $password, $dbname);

//if ($conn->connect_error) {
//  die("Connection failed: " . $conn->connect_error);
//}

    $amount = ($_GET["amount"]);
    $city =($_GET["city"]);
    $phone =($_GET["phone"]);
    $customer_name = ($_GET["customer_name"]);
    $product_id = ($_GET["product_id"]);
    $comment = ($_GET["comment"]);
    
    echo $amount;
    echo $city;
    echo $phone;
    echo $customer_name;
    echo $product_id;
    echo $comment;
    
   /* if (!isset($_POST['customer_name']) || !isset($_POST['phone']) ||
    !isset($_POST['city']) || !isset($_POST['amount']))
    {
        die ("Не все данные введены.<br>
                Пожалуйста, вернитесь назад и закончите ввод");
    }
    */
    
    $db = "sample";
    echo $city, $amount,$phone,$customer_name,$product_id,$comment;
   // mysql_select_db ( $db ) or die ("Невозможно открыть $db");
    
    $query = "INSERT INTO 'orders' (id, customer_name, city_id, phone, comment) VALUES ($product_id, $customer_name,$city, $phone, $comment)";
    
    
    $result = mysql_query ( $query );
    if ($result) echo "Success!";
    mysql_close ( $link );
    
    
}}