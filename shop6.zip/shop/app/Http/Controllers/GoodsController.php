<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Goods;
class GoodsController extends Controller
{
    public function showAction ($id){
        $product = Goods::find($id);
        if ($product) {
            return view('product', ['good' => $product]);
            
        }
    }
	public function showALLAction(){
		$procuct2 = Goods::where('category_id', 3)->get();
		
		print $product2;
		
           return view('goods_all', ['good' => $product2]);
		}
    
}
