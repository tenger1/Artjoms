Search: 
<?php 

echo htmlspecialchars($_POST['search']); 



?>
